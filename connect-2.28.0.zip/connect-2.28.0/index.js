
module.exports = require('./lib/connect');
